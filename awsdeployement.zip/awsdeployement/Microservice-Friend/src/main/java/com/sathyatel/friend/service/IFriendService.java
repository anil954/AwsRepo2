package com.sathyatel.friend.service;

import java.util.List;

import com.sathyatel.friend.entity.Friend;


public interface IFriendService {
	String addFriendService(Friend friend);
	//Friend addFreindService(Integer id);
	List<Long> getFriendsListService(Long phoneNo);

}
