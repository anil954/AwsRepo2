package com.sathyatel.calldetails.service;

import java.util.List;

import com.sathyatel.calldetails.DTO.CallDetailsDTO;

public interface ICallDetailsService {

	List<CallDetailsDTO> getCallDetailsByPhoneNumber(Long calledBy);

}
